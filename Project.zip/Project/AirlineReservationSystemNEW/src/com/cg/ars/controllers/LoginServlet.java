package com.cg.ars.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.EntityManagerFactory;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.User;

import com.cg.ars.beans.Users;
import com.cg.ars.service.AirlineServices;
import com.cg.ars.service.AirlineServicesImpl;
import com.cg.ars.util.EntityManagerFactoryProvider;

@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 11111L;
	AirlineServices services = new AirlineServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		HttpSession session = request.getSession();
		session.setAttribute("userNameTwo", userName); 
		Users user = new Users(userName);
		if(services.find(userName, password) == null){
			PrintWriter out = response.getWriter();
			out.println("<script>alert('Please Enter Valid Login Credentails!');"
					+ "location='indexPage.jsp';</script>");
		}
		else{
			RequestDispatcher dispatcher;
			dispatcher = request.getRequestDispatcher("homePage.jsp");
			request.setAttribute("userName", userName);
			dispatcher.forward(request, response);
		}
	}

}
