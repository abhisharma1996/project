package com.cg.ars.controllers;

import java.io.IOException;

import javax.persistence.criteria.CriteriaBuilder.In;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.beans.BookingInformation;
import com.cg.ars.service.AirlineServices;
import com.cg.ars.service.AirlineServicesImpl;

@WebServlet("/CancelBooking")
public class CancelBooking extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		AirlineServices services = new AirlineServicesImpl();
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		BookingInformation bookingInformation = services.viewReservationDetails(bookingId);
		services.cancelReservation(bookingId);
		RequestDispatcher dispatcher = request.getRequestDispatcher("cancelledSuccessfully.jsp");
		dispatcher.forward(request, response);
	}
}
