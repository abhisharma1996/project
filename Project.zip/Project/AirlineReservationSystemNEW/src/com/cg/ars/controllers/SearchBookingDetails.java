package com.cg.ars.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.beans.BookingInformation;
import com.cg.ars.service.AirlineServices;
import com.cg.ars.service.AirlineServicesImpl;

@WebServlet("/SearchBookingDetails")
public class SearchBookingDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AirlineServices services = new AirlineServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int bookingId = Integer.parseInt(request.getParameter("bookingId"));
		BookingInformation bookingInformation = services.viewReservationDetails(bookingId);
		request.setAttribute("bookingInformation", bookingInformation);
		RequestDispatcher dispatcher = request.getRequestDispatcher("showReservationDetails.jsp");
		dispatcher.forward(request, response);
	}
}
