package com.cg.ars.controllers;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.ars.beans.BookingInformation;
import com.cg.ars.beans.FlightInformation;
import com.cg.ars.service.AirlineServices;
import com.cg.ars.service.AirlineServicesImpl;

@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	AirlineServices services = new AirlineServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String flightNo = request.getParameter("flightNo");
		String custEmail = request.getParameter("custEmail");
		int noOfPassengers = Integer.parseInt(request.getParameter("noOfPassengers"));
		String classType = request.getParameter("classType");
		BookingInformation bookingInformation = new BookingInformation(custEmail, noOfPassengers, classType,services.findOne(flightNo));
		services.bookFlight(bookingInformation);
		request.setAttribute("bookingInformation", bookingInformation);
		RequestDispatcher dispatcher = request.getRequestDispatcher("showReservationDetails.jsp");
		dispatcher.forward(request, response);
	}

}
